import os
from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential
import base64
from cryptography.fernet import Fernet
import logging

class SecureConfiguration:
    def __init__(self):
        self.credential = DefaultAzureCredential()
        self.key_vault_url = os.environ.get('KEY_VAULT_URL')
        if not self.key_vault_url:
            raise ValueError("KEY_VAULT_URL environment variable is required")
        self.secret_client = SecretClient(vault_url=self.key_vault_url, credential=self.credential)

    def get_secure_settings(self):
        """Retrieve secure settings from Azure Key Vault"""
        try:
            settings = {
                'AZURE_STORAGE_CONNECTION': self._get_secret('AzureWebJobsStorage'),
                'AZURE_OPENAI_API_KEY': self._get_secret('AzureOpenAiKey'),
                'AZURE_OPENAI_ENDPOINT': self._get_secret('AzureOpenAiEndpoint'),
                'AZURE_OPENAI_API_VERSION': self._get_secret('AzureOpenAiVersion'),
                'AZURE_FILES_SHARE_NAME': self._get_secret('AzureFilesShareName')
            }
            return settings
        except Exception as e:
            logging.error(f"Error retrieving secure settings: {str(e)}")
            raise

    def _get_secret(self, secret_name):
        """Safely retrieve a secret from Key Vault"""
        try:
            return self.secret_client.get_secret(secret_name).value
        except Exception as e:
            logging.error(f"Error retrieving secret {secret_name}: {str(e)}")
            raise ValueError(f"Error retrieving {secret_name}: {str(e)}")

class CodeProtection:
    """Handles encryption and decryption of sensitive code files"""
    
    @staticmethod
    def generate_key():
        """Generate a new encryption key"""
        return Fernet.generate_key()

    @staticmethod
    def get_encryption_key():
        """Get or create the encryption key"""
        key = os.environ.get('CODE_ENCRYPTION_KEY')
        if not key:
            key = CodeProtection.generate_key()
            os.environ['CODE_ENCRYPTION_KEY'] = key.decode()
        return key if isinstance(key, bytes) else key.encode()

    @staticmethod
    def encrypt_skills():
        """Encrypt sensitive skill implementations"""
        try:
            key = CodeProtection.get_encryption_key()
            fernet = Fernet(key)
            skills_dir = "skills"
            
            if not os.path.exists(skills_dir):
                logging.warning(f"Skills directory {skills_dir} does not exist")
                return
            
            for skill_file in os.listdir(skills_dir):
                if skill_file.endswith('_skill.py'):
                    file_path = os.path.join(skills_dir, skill_file)
                    try:
                        with open(file_path, 'rb') as f:
                            content = f.read()
                        # Encrypt the content
                        encrypted_content = fernet.encrypt(content)
                        # Save encrypted file
                        encrypted_file = f"{file_path}.encrypted"
                        with open(encrypted_file, 'wb') as f:
                            f.write(encrypted_content)
                        logging.info(f"Encrypted {skill_file}")
                    except Exception as e:
                        logging.error(f"Error encrypting {skill_file}: {str(e)}")
                        continue

        except Exception as e:
            logging.error(f"Error in encrypt_skills: {str(e)}")
            raise

    @staticmethod
    def decrypt_skills():
        """Decrypt skills at runtime"""
        try:
            key = CodeProtection.get_encryption_key()
            fernet = Fernet(key)
            skills_dir = "skills"
            
            if not os.path.exists(skills_dir):
                logging.warning(f"Skills directory {skills_dir} does not exist")
                return
            
            for encrypted_file in os.listdir(skills_dir):
                if encrypted_file.endswith('.encrypted'):
                    file_path = os.path.join(skills_dir, encrypted_file)
                    try:
                        with open(file_path, 'rb') as f:
                            encrypted_content = f.read()
                        # Decrypt the content
                        decrypted_content = fernet.decrypt(encrypted_content)
                        # Save decrypted file
                        original_file = file_path.replace('.encrypted', '')
                        with open(original_file, 'wb') as f:
                            f.write(decrypted_content)
                        logging.info(f"Decrypted {encrypted_file}")
                    except Exception as e:
                        logging.error(f"Error decrypting {encrypted_file}: {str(e)}")
                        continue

        except Exception as e:
            logging.error(f"Error in decrypt_skills: {str(e)}")
            raise

class SecretRotation:
    """Handles automatic rotation of secrets"""
    
    def __init__(self, secure_config):
        self.secure_config = secure_config
        
    def rotate_secrets(self):
        """Implement your secret rotation logic here"""
        pass # Implement based on your security requirements
#!/bin/bash

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | grep -v '#' | awk '/=/ {print $1}')
fi

# Validate required environment variables
required_vars=("AZURE_SUBSCRIPTION_ID" "AZURE_RESOURCE_GROUP" "ENVIRONMENT_NAME" "LOCATION" "ADMIN_OBJECT_ID")
for var in "${required_vars[@]}"; do
    if [ -z "${!var}" ]; then
        echo "Error: Required environment variable $var is not set"
        exit 1
    fi
done

# Set Azure subscription
echo "Setting Azure subscription..."
az account set --subscription $AZURE_SUBSCRIPTION_ID

# Create resource group if it doesn't exist
echo "Creating resource group..."
az group create \
    --name $AZURE_RESOURCE_GROUP \
    --location $LOCATION \
    --tags Environment=$ENVIRONMENT_NAME Application=BusinessBot

# Deploy ARM template
echo "Deploying ARM template..."
deployment_output=$(az deployment group create \
    --resource-group $AZURE_RESOURCE_GROUP \
    --template-file deployment/azuredeploy.json \
    --parameters @deployment/azuredeploy.parameters.json \
    --parameters environmentName=$ENVIRONMENT_NAME \
    --parameters administratorObjectId=$ADMIN_OBJECT_ID \
    --output json)

# Extract required values from deployment
function_app_name=$(echo $deployment_output | jq -r '.properties.outputs.functionAppName.value')
key_vault_name=$(echo $deployment_output | jq -r '.properties.outputs.keyVaultName.value')
function_app_identity=$(echo $deployment_output | jq -r '.properties.outputs.functionAppIdentityPrincipalId.value')

# Configure Key Vault
echo "Configuring Key Vault..."
./deployment/scripts/setup-keyvault.sh $key_vault_name $function_app_identity

# Encrypt sensitive files
echo "Encrypting sensitive files..."
python -c "from deployment.secure_config import CodeProtection; CodeProtection.encrypt_skills()"

# Create function app deployment package
echo "Creating deployment package..."
zip -r function_app.zip . -x "*.git*" "*.env*" "deployment/*"

# Deploy function app
echo "Deploying function app..."
az functionapp deployment source config-zip \
    --resource-group $AZURE_RESOURCE_GROUP \
    --name $function_app_name \
    --src function_app.zip

echo "Deployment completed successfully!"
echo "Function App Name: $function_app_name"
echo "Key Vault Name: $key_vault_name"
#!/bin/bash

set -e

if [ $# -lt 2 ]; then
    echo "Usage: $0 <key-vault-name> <function-app-identity>"
    exit 1
fi

KEY_VAULT_NAME=$1
FUNCTION_APP_IDENTITY=$2

# Set required Key Vault access policies
echo "Setting Key Vault access policies..."
az keyvault set-policy \
    --name $KEY_VAULT_NAME \
    --object-id $FUNCTION_APP_IDENTITY \
    --secret-permissions get list \
    --key-permissions get list \
    --certificate-permissions get list

# Add required secrets
echo "Adding required secrets to Key Vault..."

# Function to safely add a secret
add_secret() {
    local secret_name=$1
    local prompt=$2
    
    # Check if secret already exists
    if az keyvault secret show --vault-name $KEY_VAULT_NAME --name $secret_name >/dev/null 2>&1; then
        read -p "Secret $secret_name already exists. Update it? (y/n) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            return
        fi
    fi
    
    # Prompt for secret value
    read -p "$prompt: " secret_value
    
    # Set the secret
    az keyvault secret set \
        --vault-name $KEY_VAULT_NAME \
        --name $secret_name \
        --value "$secret_value" \
        --output none
    
    echo "Secret $secret_name has been set"
}

# Add required secrets
add_secret "AzureOpenAiKey" "Enter Azure OpenAI API Key"
add_secret "AzureOpenAiVersion" "Enter Azure OpenAI API Version (e.g., 2023-05-15)"
add_secret "AzureOpenAiEndpoint" "Enter Azure OpenAI Endpoint URL"

echo "Key Vault configuration completed successfully!"
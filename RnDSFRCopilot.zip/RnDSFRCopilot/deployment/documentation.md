# Secure Azure Business Bot Deployment Guide

## Overview

This repository contains the infrastructure as code (IaC) and deployment instructions for securely deploying the Business Bot solution across Azure environments. The deployment uses Azure ARM templates for infrastructure provisioning and includes security best practices.

## Table of Contents

- [Prerequisites](#prerequisites)
- [Repository Structure](#repository-structure)
- [Security Features](#security-features)
- [Deployment Steps](#deployment-steps)
- [Post-Deployment Configuration](#post-deployment-configuration)
- [Troubleshooting](#troubleshooting)
- [Security Considerations](#security-considerations)

## Prerequisites

1. Azure CLI installed and configured
2. Azure subscription with required permissions
3. Azure AD permissions to create and manage identities
4. Git for version control
5. Python 3.9 or later (for local development)

## Repository Structure

```
deployment/
├── azuredeploy.json           # Main ARM template
├── azuredeploy.parameters.json # Parameters file
├── scripts/
│   ├── deploy.sh             # Deployment script
│   └── setup-keyvault.sh     # Key Vault configuration script
├── src/
│   └── secure_config.py      # Security configuration
└── README.md                 # This file
```

## Security Features

The deployment includes the following security measures:

- Azure Key Vault integration for secret management
- System-assigned managed identities
- RBAC-based access control
- Network security rules
- TLS 1.2 enforcement
- HTTPS-only access
- Private endpoints support
- Encrypted storage
- Application-level encryption for sensitive code

## Deployment Steps

### 1. Prepare Environment Variables

Create a `.env` file with the following variables:

```bash
AZURE_SUBSCRIPTION_ID="your-subscription-id"
AZURE_RESOURCE_GROUP="your-resource-group"
ENVIRONMENT_NAME="dev|prod"
LOCATION="eastus"
ADMIN_OBJECT_ID="your-admin-object-id"
```

### 2. Create Resource Group

```bash
az group create \
  --name $AZURE_RESOURCE_GROUP \
  --location $LOCATION
```

### 3. Deploy ARM Template

```bash
az deployment group create \
  --resource-group $AZURE_RESOURCE_GROUP \
  --template-file deployment/azuredeploy.json \
  --parameters @deployment/azuredeploy.parameters.json \
  --parameters environmentName=$ENVIRONMENT_NAME \
  --parameters administratorObjectId=$ADMIN_OBJECT_ID
```

### 4. Configure Key Vault

```bash
./deployment/scripts/setup-keyvault.sh
```

## Post-Deployment Configuration

### 1. Set Up Managed Identity

```bash
FUNCTION_APP_IDENTITY=$(az functionapp identity show \
  --name <function-app-name> \
  --resource-group $AZURE_RESOURCE_GROUP \
  --query principalId -o tsv)
```

### 2. Configure Secrets

Add required secrets to Key Vault:

```bash
az keyvault secret set \
  --vault-name <key-vault-name> \
  --name "AzureOpenAiKey" \
  --value "<your-openai-key>"

az keyvault secret set \
  --vault-name <key-vault-name> \
  --name "AzureOpenAiVersion" \
  --value "2023-05-15"
```

### 3. Deploy Function App Code

```bash
# Encrypt sensitive files
python -c "from deployment.secure_config import CodeProtection; CodeProtection.encrypt_skills()"

# Deploy function app
az functionapp deployment source config-zip \
  --resource-group $AZURE_RESOURCE_GROUP \
  --name <function-app-name> \
  --src function_app.zip
```

## Troubleshooting

Common issues and solutions:

1. **Deployment fails with permission errors**
   - Verify Azure AD permissions
   - Check resource provider registrations
   - Ensure subscription has required quotas

2. **Key Vault access issues**
   - Verify managed identity configuration
   - Check RBAC assignments
   - Ensure network rules allow access

3. **Function App not starting**
   - Check application settings
   - Verify Python version compatibility
   - Review application insights logs

## Security Considerations

### Access Control
- Use managed identities instead of connection strings
- Implement least-privilege access
- Regularly rotate secrets and keys

### Network Security
- Enable private endpoints where possible
- Restrict public access
- Use network security groups

### Data Protection
- Enable storage encryption
- Use TLS 1.2 or later
- Implement application-level encryption

### Monitoring
- Enable diagnostic logging
- Configure alerts
- Regular security scanning

## License

Proprietary - All rights reserved.